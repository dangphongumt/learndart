import 'package:flutter/material.dart';

class AppColors {
  static Color white = Colors.white;
  static Color grey = Color(0xFF908E8E);
  static Color black = Color(0xFF0E121B);
  static Color blue = Color(0xFF00D9F6);
}
